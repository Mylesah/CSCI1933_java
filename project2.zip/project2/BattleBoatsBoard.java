// written by halpe084 and mulle474

import java.util.Scanner;

public class BattleBoatsBoard {
    public Cell[][] myBoard;
    public BattleBoat[] myFleet;
    public int fleetIdx;
    private int numBoats;
    private int numShots;
    private int numTurns;
    private int numMissiles;
    private int numDrones;
    public boolean gameMode; // true = standard, false = expert

    ////// constructor method
    public BattleBoatsBoard(int boardSize){
        numBoats = 0;
        numShots = 0;
        numTurns = 0;
        fleetIdx = 0;
        myFleet = new BattleBoat[0];
        gameMode = true;
        numMissiles = 1;
        numDrones = 1;
        if(boardSize == 12){ //expert mode
            gameMode = false;
            numMissiles = 2;
            numDrones = 2;
        }
        this.myBoard = new Cell [boardSize][boardSize];

        for(int i =0; i< boardSize; i++){ //fill empty cells to prevent null errors
            for(int j = 0; j< boardSize; j++){
                Cell emptyCell = new Cell(i,j,'-',0);
                myBoard[i][j] = emptyCell;
            }
        }
    }
    ////// helper methods for placeBoats are:
    ////// checkSpot: checks to see if a boat already exists there
    ////// newSpot: which creates a new spot to start building your boat using checkSpot to make sure it is empty
    ///// randomDirection return true/false randomly
    ////// buildBoats: calls newSpot() and randomDirection() to start and builds boat based on length
    ////// addBoats: will add a BattleBoat to myFleet and increase array length by 1
    ////// placeBoats: calls buildBoats() and then checks all the boat pieces with checkSpot then adds calls addBoats() to add to fleet,
    ////// it does this for 1x5, 1x4, 2x3, 1x2 boats, plan to call placeBoats() twice when expert gameMode selected

    public boolean checkSpot(Cell aSpot){
        boolean isEmpty = true; //spot available if false, spot taken
        for(int i = 0; i < myFleet.length; i++){
            int jLength = myFleet[i].getLength();
            for(int j = 0; j < jLength; j++){
                if(aSpot.row == myFleet[i].getCell(j).row && aSpot.col == myFleet[i].getCell(j).col){
                    //System.out.println("taken");
                    isEmpty = false;
                }

            }
        }
        if(aSpot.row >= myBoard.length | aSpot.col >= myBoard.length){ // check bounds
            isEmpty = false;
        }
        return isEmpty;
    }

    public Cell newSpot(int boatLength){
        Cell emptySpot = new Cell(0,0,'-',0);
        boolean validSpot = false;

        while(validSpot == false){
            int row = (int)(Math.random()*myBoard.length);
            int col = (int)(Math.random()*myBoard.length);
            emptySpot = new Cell(row,col,'B', boatLength); ////newSpot created here with our random values
            if(this.checkSpot(emptySpot) == true){
                validSpot = true;
            }
        }
        //System.out.println(emptySpot.row + "row"); //my tests seem to show that this helper function is working
        //System.out.println(emptySpot.col + "col");
        return emptySpot;
    }

    public boolean randomDirection(){
        int oddEven = (int)((Math.random()*10) + 1); // gives us random int 1 - 10, even = false, odd = true for random boolean value
        if(oddEven % 2 == 0){
            return false;
        }
        return true;
    }

    public BattleBoat buildBoats(int boatLength){ /// builds boat of given parameter length and returns BattleBoat object
        Cell startPiece = newSpot(boatLength); // randomly generated start piece
        Cell[] boatPieces = new Cell[boatLength];
        boatPieces[0] = startPiece; //start piece is zero index and start of our cell array
        int rowA = startPiece.row;
        int colA  = startPiece.col;
        boolean hOrv = randomDirection(); /// randomly chooses to build vertically or horizantally
        for(int i = 1; i < boatLength; i++){
            if(hOrv == true){
                colA += 1; // build horiz
            }
            else{
                rowA += 1; // build vert
            }
            Cell nextP = new Cell(rowA, colA, 'B', boatLength);
            boatPieces[i] = nextP; // adding new cell objects to array
        }
        BattleBoat myBoat = new BattleBoat(boatLength, hOrv, boatPieces); //create BattleBoat object from cell array and other vars
        return myBoat;
    }

    public void addBoats(BattleBoat newBoat){ /// builds out the fleet by 1 boat and adds new boat
        BattleBoat[] newFleet = new BattleBoat[myFleet.length + 1];
        for(int i = 0; i < myFleet.length; i++){
            newFleet[i] = myFleet[i];
        }
        newFleet[fleetIdx] = newBoat;
        fleetIdx += 1; // keep track of where our next new boat will go
        myFleet = newFleet;

        for(int i =0; i < newBoat.getLength(); i++){
            int myRow = newBoat.getCell(i).row;
            int myCol = newBoat.getCell(i).col;
            myBoard[myRow][myCol] = newBoat.getCell(i);
        }
    }

    public int placeBoats(){
        int testIt = 1;
        BattleBoat fiveA = buildBoats(5); // selects boat length
        for(int i = 0; i <5; i++){
            if(checkSpot(fiveA.getCell(i)) == false){ //checks for overlap, if there is overlap/out of bounds...
                fiveA = buildBoats(5); // ... create new boat to test and start over with "i = 0"
                i = 0;
            }
        }
        this.addBoats(fiveA);
        BattleBoat fourA = buildBoats(4); //same process as above repeated for all boats
        for(int i = 0; i <4; i++){
            if(checkSpot(fourA.getCell(i))== false){
                fourA = buildBoats(4);
                i = 0;
            }
        }
        this.addBoats(fourA);
        BattleBoat threeA = buildBoats(3);
        for(int i = 0; i <3; i++){
            if(checkSpot(threeA.getCell(i))== false){
                threeA = buildBoats(3);
                i = 0;
            }
        }
        this.addBoats(threeA);
        BattleBoat threeB = buildBoats(3);
        for(int i = 0; i <3; i++){
            if(checkSpot(threeB.getCell(i))== false){
                threeB = buildBoats(3);
                i = 0;
            }
        }
        this.addBoats(threeB);
        BattleBoat twoA = buildBoats(2);
        for(int i = 0; i <2; i++){
            if(checkSpot(twoA.getCell(i))== false){
                twoA = buildBoats(2);
                i = 0;
            }
        }
        this.addBoats(twoA);
        this.numBoats += 5;
        return testIt;
    }

    public String fire(int row, int col) {
        numTurns += 1;
        numShots += 1;
        String printOut = "";
        if(row >= myBoard.length | col >= myBoard.length){ //out of bounds
            printOut = "penalty, out of bounds";
            numTurns += 1;
            return printOut;
        }
        if(myBoard[row][col].get_status() == 'M' | myBoard[row][col].get_status() == 'H') { //already guessed spots
            printOut = "penalty";
            numTurns += 1;
            return printOut;
        }
        if(myBoard[row][col].get_status() == '-') { //new guess but miss
            myBoard[row][col].set_status('M');
            printOut = "miss";
            return printOut;
        }
        for (int i = 0; i < myFleet.length; i++) {
            //myFleet[i]
            for (int j = 0; j < myFleet[i].getLength(); j++) {
                char pieceStatus = myFleet[i].getCell(j).get_status();
                if (myFleet[i].getCell(j).row == row & myFleet[i].getCell(j).col == col) { //if equal to a boat
                    if (pieceStatus == 'B') { // hit
                        myFleet[i].setCell(j,'H');
                        myBoard[row][col].set_status('H');
                        boolean allHit = true;
                        for(int k =0; k < myFleet[i].getLength(); k++){
                            if(myFleet[i].getCell(k).get_status() == 'B'){
                                allHit = false;display();
                            }
                        }
                        printOut = "hit";
                        if(allHit == true){
                            numBoats -= 1;
                            printOut = "you sunk a boat, " + numBoats + " remaining";
                        }
                    }
                }
            }
        }
        return printOut;
    }

    public String display(){
        String end = "";
        for(int row = 0; row < myBoard.length; row++) {
            String oldS = "";
            end = end + "\n";
            for (int col = 0; col < myBoard.length; col++) {
                if(myBoard[row][col].get_status() == 'B' | myBoard[row][col].get_status() == '-'){ //hidden
                    oldS = "- ";
                }
                if(myBoard[row][col].get_status() == 'M'| myBoard[row][col].get_status() == 'O'){ //show miss/no boat from drone
                    oldS = "O ";
                }
                if(myBoard[row][col].get_status() == 'H'){ //already hit
                    oldS = "X ";
                }

                end = end + oldS;
            }
        }
        return end;
    }

    public String print(){ //if boat has not been hit show length of boat similar structure to display
        //Character.toString
        String end = "";
        for(int row = 0; row < myBoard.length; row++) {
            String oldS = "";
            end = end + "\n";
            for (int col = 0; col < myBoard.length; col++) {
                if(myBoard[row][col].get_status() == 'B'){
                    for(int i = 0; i < myFleet.length; i++){
                        for(int j = 0; j< myFleet[i].getLength(); j++){
                            int r = myFleet[i].getCell(j).row;
                            int c = myFleet[i].getCell(j).col;
                            if(r == row & c == col){
                                oldS = Integer.toString(myFleet[i].getCell(j).get_type()) + " ";
                            }
                        }
                    }
                }
                if(myBoard[row][col].get_status() == 'M' | myBoard[row][col].get_status() == 'O'){
                    oldS = "O ";
                }
                if(myBoard[row][col].get_status() == 'H'){
                    oldS = "X ";
                }
                if(myBoard[row][col].get_status() == '-') {
                    oldS = "- ";
                }
                end = end + oldS;
            }
        }
        return end;
    }

    /////////////////////////////////////MISSILES///////////////////////////////////////
    ///////missileHelp() is helper method with similar structure to fire(), just changed slightly for missile()

    public void missileHelp(int row, int col){
        int num_misses = 0;
        int num_hits = 0;
        int num_sinks =0;
        if(row < 0 | col < 0){
            num_misses += 1;
        }
        if(row >= myBoard.length | row >= myBoard.length){
            num_misses += 1;
        }
        if(myBoard[row][col].get_status() == 'M' | myBoard[row][col].get_status() == 'H'){
            num_misses += 1;
        }
        if(myBoard[row][col].get_status() == '-'){
            myBoard[row][col].set_status('M');
            num_misses += 1;
        }
        for (int i = 0; i < myFleet.length; i++) {
            for (int j = 0; j < myFleet[i].getLength(); j++) {
                char pieceStatus = myFleet[i].getCell(j).get_status();
                if (myFleet[i].getCell(j).row == row & myFleet[i].getCell(j).col == col) { //if equal to a boat
                    if (pieceStatus == 'B') { // hit
                        myFleet[i].setCell(j,'H');
                        myBoard[row][col].set_status('H');
                        boolean allHit = true;
                        for(int k =0; k < myFleet[i].getLength(); k++){
                            if(myFleet[i].getCell(k).get_status() == 'B'){
                                allHit = false;display();
                            }
                        }
                        if(allHit == true){
                            numBoats -= 1;
                        }
                    }
                }
            }
        }
    }

    public String missile(int row, int col){ //calls missileHelp
        numMissiles -= 1;
        numTurns += 1;
        row -= 2;
        col -= 2;
        //String printOut = "";
        for(int i = 0; i < 3; i++) {
            col += 1;

            for (int j = 0; j < 3; j++) {
                row += 1;
                if((row >= 0 & row < myBoard.length)&(col >= 0 & col < myBoard.length)){
                    missileHelp(row,col);
                }
            }
            row -= 3;
        }
        String missileS = "missile fired... check scanner below for damage analysis";
        return missileS;
    }

    /////////////////////////////////DRONE////////////////////////////////////////////////////

    public String drone(String rowCol, int n){

        numDrones -= 1;
        numTurns += 1;
        int num_empty = 0;
        int num_boats = 0;
        String boatCell = "";
        String boatsIn = "";
        String emptyS = "";

        for(int i = 0; i < myBoard.length; i++) {

            if (rowCol.equals("r")) {
                if (myBoard[n][i].get_status() == '-' | myBoard[n][i].get_status() == 'M') {
                    myBoard[n][i].set_status(('O'));
                    num_empty += 1;
                }
                if (myBoard[n][i].get_status() == 'B') {
                    boatsIn = "(" + n +", " + i + ")";
                    boatCell = boatsIn + emptyS;
                    emptyS = boatCell;
                    num_boats += 1;
                }
                if(myBoard[n][i].get_status() == 'H'){
                    num_boats += 1;
                }

            }
            if (rowCol.equals("c")) {
                if (myBoard[i][n].get_status() == '-' | myBoard[i][n].get_status() == 'M') {
                    myBoard[i][n].set_status(('O'));
                    num_empty += 1;
                }
                if (myBoard[i][n].get_status() == 'B') {
                    boatsIn = "(" + i +", " + n + ")";
                    boatCell = boatsIn + emptyS;
                    emptyS = boatCell;
                    num_boats += 1;
                }
                if(myBoard[i][n].get_status() == 'H'){
                    num_boats += 1;
                }
            }
        }
        String enterIn = "row ";
        if(rowCol.equals("c")){
            enterIn = "column ";
        }
        String myString = "Your drone spotted " + num_boats + " enemy vessel spaces in " + enterIn + n +"\n locations: " + boatCell;
        return myString;
    }

    ///////////////////////////////////////////////////////////////////////////////

    public String userInput(){
        Scanner myScanner = new Scanner(System.in);
        System.out.println(this.display());
        System.out.println("choose your move: f for fire, d for drone, m for missile, p for print");
        String userIn = myScanner.nextLine();
        while(!userIn.equals("f") & !userIn.equals("d") & !userIn.equals("m") & !userIn.equals("p")){
            System.out.println("Please choose a valid input: f, d, m, or p");
            userIn = myScanner.nextLine();

        }
        return userIn;
    }

   public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        System.out.println("select difficulty: s for standard, e for expert");
        String gameSetting = myScanner.nextLine();
        BattleBoatsBoard gameBoard = new BattleBoatsBoard(8);
        while(!gameSetting.equals("s") & !gameSetting.equals("e")){
            System.out.println("only type letter s or e");
            gameSetting = myScanner.nextLine();
        }
        if(gameSetting.equals("s")){ //standard
            gameBoard.placeBoats();
            System.out.println("five enemy boats in your area... take them out!");
        }
       if(gameSetting.equals("e")){ //expert
           gameBoard = new BattleBoatsBoard(12);
           gameBoard.placeBoats();
           gameBoard.placeBoats();
           System.out.println("ten enemy boats in your area... take them out!");
       }
       //System.out.println(gameBoard.display());
       while(gameBoard.numBoats > 0) {
           String userIn = gameBoard.userInput();
           if(userIn.equals("f")){
               System.out.println("choose row");
               int row = myScanner.nextInt();
               System.out.println("choose col");
               int col = myScanner.nextInt();
               System.out.println("you selected: (" + row + ", " + col + ")");
               System.out.println(gameBoard.fire(row,col));
           }
           if(userIn.equals("p")){
               System.out.println(gameBoard.print());
           }
           if(userIn.equals("m")){
               if(gameBoard.numMissiles <= 0){
                   System.out.println("Sorry bud no missiles left.");
               }
               else{
                   System.out.println("preparing to launch...");
                   System.out.println("choose row");
                   int rowM = myScanner.nextInt();
                   System.out.println("choose col");
                   int colM = myScanner.nextInt();
                   while(rowM > gameBoard.myBoard.length | colM > gameBoard.myBoard.length | rowM < 0 | colM < 0){
                       System.out.println("are you crazy?! there's nothing there, pick again...");
                       System.out.println("choose row");
                       rowM = myScanner.nextInt();
                       System.out.println("choose col");
                       colM = myScanner.nextInt();
                   }
                   System.out.println("you selected: (" + rowM + ", " + colM + ")");
                   System.out.println(gameBoard.missile(rowM,colM));
                   System.out.println("you have " + gameBoard.numMissiles + " missile(s) left");

               }
           }
           if(userIn.equals("d")){
               if(gameBoard.numDrones <= 0){
                   String allOut = "drones don't grow on trees ya know";
                   System.out.println(allOut);
               }
               else{
                   System.out.println("launching drone...");
                   System.out.println("please enter if you want to scan a row ('r') or column ('c')");
                   String rowCol = myScanner.nextLine();
                   while(!rowCol.equals("r") & !rowCol.equals("c")){ /////////////
                       System.out.println("please only enter letter r or c");
                       rowCol = myScanner.nextLine();
                   }
                   System.out.println("Now select the number row/column you want to scan");
                   int scanN = myScanner.nextInt();
                   while(scanN<0 | scanN > (gameBoard.myBoard.length - 1)){
                       System.out.println("serious bro? there aren't any boats over there... choose again");
                       scanN = myScanner.nextInt();
                   }
                   System.out.println(gameBoard.drone(rowCol, scanN));
               }

           }
       }
       System.out.println(gameBoard.print());
       System.out.println("You took " + gameBoard.numTurns + " turns and " + gameBoard.numShots + " shots, not bad... \nfor a rookie");

   }
}
