Myles Halpern - halpe084
Matthew Mullen - mulle474

1. Myles did Cell and BattleBoats class, and BattleBoatsBoard methods: placeBoats() (including helper methods), and BattleBoatsBoard() constructor method. Matthew did fire(), missile(), drone(), print(), and display(). We still worked together collaboreatley, not one person did a whole piece alone. We wrote most of the main together. 

2. Run main() mehtod in BattleBoatsBoard.java:
> javac BattleBoatsBoard.java (compile)
> java BattleBoatsBoard (run)
I didn't realize that I should make a BattleBoatsGame class until after the fact so the game runs from BattleBoatsBoad. 

3. Bugs: I know that for some user inputs that don't match object type (int versus String) there are a couple times I didn't create that catch error and try cases for those errors. Also for drone(), I was able to generate "O"s for empty spaces but had problems when trying to fill spaces that the drone found with boats with chars 'B' and I tried other chars like '?' when reading directions for drone it originally didn't say it needed to be reflected in the game board just to return the number of boats found, that piece of info was in a different part of the project pdf so I had already started that method without the feature. Essentially the drone() defect came down to the fact that I did a couple things in a weird order earlier and in order to change the state of those cells to show up when a drone found a boat for display() it would've caused errors with other functions like fire and missile. Instead I adjusted for this by having the drone class just print out all the coordinates: (row,col) for the user that they scanned if there was a boat so they could write down the coordinates on paper to make it fair. 
