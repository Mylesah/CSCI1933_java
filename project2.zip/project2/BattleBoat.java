// written by halpe084
public class BattleBoat {
    private int bLength;
    private boolean bOrient;
    private Cell[] bLocation;

    public BattleBoat(int bLength, boolean bOrient, Cell[] bLocation){
       this.bLength = bLength;
       this.bOrient = bOrient;
       this.bLocation = bLocation;
    }

    public char get_status(Cell aPoint){
        char cellStat = '\0';
        for(int i = 0; i < bLocation.length; i++){
            if(bLocation[i].row == (aPoint.row) && bLocation[i].col == (aPoint.col)){
               cellStat = bLocation[i].status;
            }
        }
        return cellStat;

    }
    public boolean getOrient(){
        return bOrient;
    }

    public int getLength(){
        return bLength;
    }

    public Cell getCell(int idx){
        return bLocation[idx]; //return Cell object for one piece of the boat so we can test individual pieces
    }

    public void setCell(int idx, char status){
        bLocation[idx].set_status(status);
    }

    public static void main(String[] args) {
        Cell a = new Cell(0, 0, '-',3);
        Cell b = new Cell(0, 1, 'b',3);
        Cell c = new Cell(0, 2, 'c',3);
        Cell d = new Cell(0,0,'d',3);
        Cell[] allABC = new Cell[] {a,b,c};
        BattleBoat aShip = new BattleBoat(3, true, allABC); // true means horiz, false means vert
        System.out.println(aShip.get_status(d));


    }


}
