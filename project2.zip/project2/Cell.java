// written by halpe084
public class Cell {
    public int row;
    public int col;
    public char status; // - = no boat no guess, B = boat but no guess, H = guessed and boat present, M = no boat but guessed
    public int typeBoat; // added this to make print() method easier, 0 = no boat, 5 = 5 length boat, etc...


    public Cell(int row, int col, char status, int typeBoat){
        this.row = row;
        this.col = col;
        this.status = status;
        this.typeBoat = typeBoat;
    }

    public Cell(){
        row = 0;
        col = 0;
        status = '-';
        typeBoat = 0;
    }
    public void set_status(char c){
        status = c;
    }
    public char get_status(){
        return status;
    }
    public int get_type(){
        return typeBoat;
    }

}


