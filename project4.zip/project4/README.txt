Sara Finnegan - finne291
Myles Halpern - halpe084

1. Myles wrote most of makeMaze() and the associated helper methods, neighorCheck() and chooseRand(). Sara wrote printMaze() and the associated helper, printHelper(). Sara and Myles worked together to write the solveMaze() method, and used the similar method, neighborCheck() to write the new helper method, reachable(). Myles wrote the README.  

2. No assumptions(?). Code is written to take in user input to choose rows and columns from the main().

3. Was unsure how TAs wanted to grade/check this project. We implemented a couple of lines using the Scanner to take user input for maze dimmensions inside main(). For testing purposes it would be easy to comment out or delete if you needed. Stack is used in makeMaze() and queues in solveMaze(); in our helpers we used arrays but if we wanted to decrease bigO notation it might've made more sense to have used a stack or queue in the helpers as well.

4. Handles negative and zero user inputs but for user input of "1" for number of rows it will look like it has two rows. This is due to the nature of the printMaze() method. We could've spent time to write a specific "if" statement to mitigate this but seemed like it is better to just anotate it here and not overcomplicate the code.

5. Credit to TA Michael Markiewicz for "Stack1Gen<int[]> aStack = new Stack1Gen<int[]>()". Originally we were conffused with what data type went in the stack and how to implement it so he suggested this code to get us started. 
