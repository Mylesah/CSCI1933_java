// Names: Myles Halpern, Sara Finnegan
// x500s: halpe084, finne291

import java.util.Objects;
import java.util.Random;
import java.util.Scanner;

public class MyMaze{
    Cell[][] maze;

    public MyMaze(int rows, int cols) {
        maze = new Cell[rows][cols];
        for(int i = 0; i < rows; i++){
            for(int j = 0; j < cols; j++){
                maze[i][j] = new Cell();
            }
        }
    }

    /* TODO: Create a new maze using the algorithm found in the writeup. */
    public static MyMaze makeMaze(int rows, int cols) {
        MyMaze m = new MyMaze(rows, cols);
        Stack1Gen<int[]> s = new Stack1Gen<int[]>();
        int[] startM = {0,0};
        s.push(startM); //pushed start index to stack
        m.maze[0][0].setVisited(true);
        //int count = 0;
        while(!s.isEmpty()){
            int[] current = s.top(); //get top element off stack
            char[] openChars = m.neighborCheck(current, rows, cols, m); // will get array of characters that are open
            char randNeighbor = m.chooseRand(openChars); //will choose random direction for the next neighbor

            ////four "if" statements for the cardinal directions, fifth "if" is to pop() if no neighbors are unvisited////
            //count += 1;
            if(randNeighbor == 'u'){ // will move up
                int x = current[0] -1;
                int[] neighbor = {x, current[1]};
                s.push(neighbor); //Add the neighbor's index to the stack
                m.maze[neighbor[0]][neighbor[1]].setVisited(true); // mark neighbor as visited
                m.maze[neighbor[0]][neighbor[1]].setBottom(false); //remove wall between current and neighbor cells
            }
            if(randNeighbor == 'd'){ // will move down
                int x = current[0] + 1;
                int[] neighbor = {x, current[1]};
                s.push(neighbor); //Add the neighbor's index to the stack
                m.maze[neighbor[0]][neighbor[1]].setVisited(true); // mark neighbor as visited
                m.maze[current[0]][current[1]].setBottom(false); //remove wall between current and neighbor cells
            }
            if(randNeighbor == 'l'){ // will move left
                int y = current[1] - 1;
                int[] neighbor = {current[0], y};
                s.push(neighbor); //Add the neighbor's index to the stack
                m.maze[neighbor[0]][neighbor[1]].setVisited(true); // mark neighbor as visited
                m.maze[neighbor[0]][neighbor[1]].setRight(false); //remove wall between current and neighbor cells
            }
            if(randNeighbor == 'r'){ // will move right
                int y = current[1] + 1;
                int[] neighbor = {current[0], y};
                s.push(neighbor); //Add the neighbor's index to the stack
                m.maze[neighbor[0]][neighbor[1]].setVisited(true); // mark neighbor as visited
                m.maze[current[0]][current[1]].setRight(false); //remove wall between current and neighbor cells
            }
            if(randNeighbor == 'p'){ //pop the element because no unvisited neighbors
                s.pop();
            }
        }
        for(int i = 0; i < m.maze.length; i++){
            for(int j = 0; j< m.maze[0].length; j++){
                m.maze[i][j].setVisited(false);
            }
        }
        return m;
    }

    //checks bounds for possible neighbors, checks which neighbors aren't visited
    public char[] neighborCheck(int[] elem, int rows, int cols, MyMaze m){
        char[] possibles = new char[4];
        int size = 0; //excessive variables but it helped me keep track of everything
        int test = 0;
        if(elem[0] - 1 >= 0){
            size += 1;
            if(m.maze[elem[0] -1][elem[1]].getVisited() == false){
                possibles[0] = 'u';
                test += 1;
            }
        }
        else {possibles[0] = ' ';}
        if(elem[0] + 1 < rows){
            size += 1;
            if(m.maze[elem[0] +1][elem[1]].getVisited() == false){
                possibles[1] = 'd';
                test += 1;
            }
        }
        else {possibles[1] = ' ';}
        if(elem[1] - 1 >= 0){
            size += 1;
            if(m.maze[elem[0]][elem[1] - 1].getVisited() == false){
                possibles[2] = 'l';
                test += 1;
            }
        }
        else {possibles[2] = ' ';}
        if(elem[1] + 1 < cols){
            size += 1;
            if(m.maze[elem[0]][elem[1] + 1].getVisited() == false){
                possibles[3] = 'r';
                test += 1;
            }
        }
        else {possibles[3] = ' ';}
        if(test == 0){
            char[] popIt = {'p'}; //no unvisited neighbors, time to pop
            return popIt;
        }
        char[] myChars = new char[test];
        int j =0;
        for(int i=0; i < possibles.length; i++){
            if(possibles[i] == 'u' | possibles[i] == 'l' | possibles[i] == 'd' | possibles[i] == 'r'){
                myChars[j] = possibles[i];
                j++;
            }
        }
        return myChars;
    }

    // randomly selects a char from array generated in neighborCheck() or returns one char if only one option or 'p' for pop
    public char chooseRand(char[] chars){
        if(chars.length == 1){ //pop case
            return chars[0];
        }
        int a = (int)((Math.random()* chars.length));
        return chars[a];
    }


    /* TODO: Print a representation of the maze to the terminal */
    public String printHelper(Cell c) {
        if(c.getVisited() == false){
            if(c.getBottom() == false && c.getRight() == false){
                return "    ";
            }
            if(c.getBottom() == false && c. getRight() == true){
                return "   |";
            }
            if(c.getBottom() == true && c. getRight() == false){
                return "____";
            }
            if(c.getBottom() == true && c.getRight() == true){
                return "___|";
            }
        }
        if(c.getVisited() == true){
            if(c.getBottom() == false && c.getRight() == false){
                return " *  ";
            }
            if(c.getBottom() == false && c. getRight() == true){
                return " * |";
            }
            if(c.getBottom() == true && c. getRight() == false){
                return "_*__";
            }
            if(c.getBottom() == true && c.getRight() == true){
                return "_*_|";
            }
        }
        return null;
    }

    public String printMaze(){
        String end = "";
        for(int i =0; i< maze[0].length; i++){ //prints top wall
            end = end + "____";
        }
        end = end + "_\n_"; //opens entrance
        for(int i = 0; i< maze[0].length; i++){
            end = end + printHelper(maze[0][i]);
        }
        for(int row = 1; row < maze.length - 1; row++) {
            String oldS = "";
            end = end + "\n|"; //prints left walls
            for (int col = 0; col < maze[0].length; col++) {
                oldS = printHelper(maze[row][col]);
                end = end + oldS;
            }
        }
        end = end + "\n|";
        for(int j = 0; j< maze[0].length - 1; j++){
            end = end + printHelper(maze[maze.length - 1][j]);
        }
        if(maze[maze.length -1][maze[0].length - 1].getVisited() == false){
            end = end + "____"; //opens exit
        }
        else{
            end = end + "_*__"; //opens exit
        }
        return end;
    }

    /* TODO: Solve the maze using the algorithm found in the writeup. */
    public void solveMaze() {
        Q1Gen<int[]> q = new Q1Gen<int[]>();
        int[] start = {0,0};
        maze[0][0].setVisited(true);
        int[] end = {maze.length -1, maze[0].length -1};
        q.add(start);
        while(!q.isEmpty()){
            int[] current = q.remove();
            char[] neighborElem = reachable(current);
            maze[current[0]][current[1]].setVisited(true);
            if(current[0] == end[0] && current[1] == end[1]){
                break;
            }
            for(int i = 0; i < neighborElem.length; i++){
                if(neighborElem[i] == 'l'){
                    int[] next = {current[0], current[1] - 1};
                    q.add(next);
                }
                if(neighborElem[i] == 'r'){
                    int[] next = {current[0], current[1] + 1};
                    q.add(next);

                }
                if(neighborElem[i] == 'u'){
                    int[] next = {current[0] -1, current[1]};
                    q.add(next);

                }
                if(neighborElem[i] == 'd'){
                    int[] next = {current[0] +1, current[1]};
                    q.add(next);
                }
            }
        }
    }
    // similar function to neighbor check finds cells that are accessible and open
    public char[] reachable(int[] elem){
        char[] moves = {' ', ' ', ' ', ' '};
        int numMoves = 0;
        if(elem[1] + 1 < maze[0].length){
            if(maze[elem[0]][elem[1]].getRight() == false){
                if(maze[elem[0]][elem[1] +1].getVisited() == false){
                    moves[0] = 'r';
                    numMoves += 1;
                }
            }
        }
        if(elem[1] - 1 >= 0){
            if(maze[elem[0]][elem[1] -1].getRight() == false){
                if(maze[elem[0]][elem[1] - 1].getVisited() == false){
                    moves[1] = 'l';
                    numMoves += 1;
                }
            }
        }
        if(elem[0] + 1 < maze.length){
            if(maze[elem[0]][elem[1]].getBottom() == false){
                if(maze[elem[0] +1][elem[1]].getVisited() == false){
                    moves[2] = 'd';
                    numMoves += 1;
                }
            }
        }
        if(elem[0] - 1 >= 0){
            if(maze[elem[0] -1][elem[1]].getBottom() == false){
                if(maze[elem[0] -1][elem[1]].getVisited() == false){
                    moves[3] = 'u';
                    numMoves += 1;
                }
            }
        }
        char[] finalArr = new char[numMoves];
        int j = 0;
        for(int i = 0; i < 4; i++){
            if(moves[i] == 'u' | moves[i] == 'd' | moves[i] == 'l' | moves[i] == 'r'){
                finalArr[j] = moves[i];
                j++;
            }
        }
        return finalArr;
    }

    public static void main(String[] args){
        Scanner myScanner = new Scanner(System.in);

        System.out.println("select number of rows");
        int rows = myScanner.nextInt();
        while(rows <= 0){
            System.out.println("choose a number greater then zero");
            rows = myScanner.nextInt();
        }
        System.out.println("select number of columns");
        int cols = myScanner.nextInt();
        while(cols <= 0){
            System.out.println("choose a number greater then zero");
            cols = myScanner.nextInt();
        }
        MyMaze m = makeMaze(rows, cols);
        System.out.println("\nyour " + rows + " X " + cols + " maze:");
        System.out.println(m.printMaze());
        m.solveMaze();
        System.out.println("\nwe took the liberty of solving your maze for you!");
        System.out.println(m.printMaze());
    }
}
