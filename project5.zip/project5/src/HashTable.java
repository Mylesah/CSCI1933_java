// myles halpern - halpe084
// sara finnegan - finne291

public class HashTable<T>{
    private NGen<T>[] hashT;
    private int unique;
    private int nonEmpty;
    private int longest;
    private int omitted;

    public HashTable(int hashLength){
        hashT = new NGen[hashLength]; // chooses different array lengths inside scan() method
        unique = 0;
        nonEmpty = 0;
        longest = 0;
        omitted = 0;
    }

    /// specific to keywords///
    public int hashKeywords(T item){
        if(item == null){
            return -1;
        }
        int hashIdx = 0;
        String s = item.toString();
        if(s.length() == 1){
            hashIdx = s.charAt(0);
        }
        if(s.length() >= 2){
            hashIdx = ((s.charAt(0) + s.charAt(1))) +  s.charAt(s.length() - 1) * s.length()* s.length();
        }
        hashIdx = (hashIdx) % hashT.length;
        return hashIdx;
    }


    ///general hash number 1///
    public int hash1(T item) {
        if (item == null) {
            return -1;
        }
        int hashIdx = 0;
        String s = item.toString();
        if (s.length() == 1) {
            hashIdx = s.charAt(0);
        }
        if (s.length() >= 2) {
            hashIdx = (s.charAt(0) + s.charAt(1)) * 23 + (s.charAt(s.length() - 2) + s.charAt(s.length() - 1))* s.length();
        }
        hashIdx = (hashIdx) % hashT.length;
        return hashIdx;
    }

    ///general hash number 2///
    public int hash2(T item) {
        if (item == null) {
            return -1;
        }
        int hashIdx = 0;
        String s = item.toString();
        if (s.length() == 1) {
            hashIdx = s.charAt(0) * 11;
        }
        if (s.length() == 2) {
            hashIdx = (s.charAt(0)) + (s.charAt(1)) * 13;
        }
        if (s.length() >= 3) {
            hashIdx = (s.charAt(0) + s.charAt(1)) * 29 + s.charAt(2) * 19;
        }
        hashIdx = (hashIdx) % hashT.length;
        return hashIdx;
    }

    ///general hash number 3///
    public int hash3(T item) {
        if (item == null) {
            return -1;
        }
        int hashIdx = 0;
        String s = item.toString();
        if (s.length() == 1) {
            hashIdx = s.charAt(0) * 7;
        }
        if (s.length() == 2) {
            hashIdx = 31 * (s.charAt(1) + s.charAt(0));
        }
        if (s.length() >= 3) {
            hashIdx = 5 * (s.charAt(0)) + (s.charAt(1) + s.charAt(2)) * 97 ;
        }
        hashIdx = (hashIdx) % hashT.length;
        return hashIdx;
    }

    public void add(T item){
        int hashIdx = hash1(item); //try the different hash functions here

        if(hashIdx < 0){ //null element passed
            return;
        }
        ////run if empty at this index////
        if(hashT[hashIdx] == null){
            NGen elem = new NGen(item, null);
            hashT[hashIdx] = elem;
            unique += 1;
            nonEmpty += 1;
            return;
        }
        ////if index is not empty////
        if(hashT[hashIdx] != null){
            ///checks if token is unique///
            NGen ptr = hashT[hashIdx];
            int newLongest = 1;
            while(ptr != null){
                if(ptr.getData().equals(item)){
                    omitted += 1;
                    return;
                }
                ptr = ptr.getNext();
                newLongest += 1;
            }
            if(newLongest > longest){
                longest = newLongest;
            }
            ///if unique///
            unique += 1;
            NGen elem = new NGen(item, hashT[hashIdx]);
            hashT[hashIdx] = elem;
        }
    }

    ///runs specifically in Scan() for keywords.txt only instead of add()///
    public void addKeywords(T item){
        int hashIdx = hashKeywords(item); // uses hashKeywords() not the general hash1() method
        if(hashIdx < 0){ //null element passed
            return;
        }
        if(hashT[hashIdx] == null){
            NGen elem = new NGen(item, null);
            hashT[hashIdx] = elem;
            unique += 1;
            nonEmpty += 1;
            return;
        }
        if(hashT[hashIdx] != null){
            NGen ptr = hashT[hashIdx];
            int newLongest = 1;
            while(ptr != null){
                if(ptr.getData().equals(item)){
                    omitted += 1;
                    return;
                }
                ptr = ptr.getNext();
                newLongest += 1;
            }
            if(newLongest > longest){
                longest = newLongest;
            }
            unique += 1;
            NGen elem = new NGen(item, hashT[hashIdx]);
            hashT[hashIdx] = elem;
        }
    }
    ///this method was a test Display method that I was using to help me visualize stuff///

    /* public void displayFull(){
        System.out.println("Number of elements added into hash table: " + unique + "\n");
        for(int i = 0; i < hashT.length; i++){
            if(hashT[i].getData() != null){
                System.out.println("idx: " + i + "\n");
                System.out.println(hashT[i].getData());
                NGen ptr = hashT[i].getNext();
                while(ptr.getNext() != null){
                    System.out.println(ptr.getData());
                    ptr = ptr.getNext();

                }
            }
        }
    }*/

    public void display(){
        //int test = 0;
        for(int i = 0; i < hashT.length; i++){
            if(hashT[i] == null){
                System.out.println(i + ": 0");
            }
            int numLinks = 1;
            if(hashT[i] != null){
                NGen ptr = hashT[i].getNext();
                while(ptr != null){
                    numLinks += 1;
                    ptr = ptr.getNext();
                }
                //test += numLinks;
                System.out.println(i + ": " + numLinks);
            }

        }
        //System.out.println("test: " + test);
        //System.out.println("omitted: " + omitted);
        //System.out.println("unique: " + unique + " nonEmpty: " + nonEmpty);
        System.out.println();
        System.out.println("average collision length: " + (unique/nonEmpty));
        System.out.println("longest chain: " + longest);
    }

    public static void main(String[] args) {
        TextScan t = new TextScan();
        System.out.println("\n--------------------- General Case ---------------------");
        ///General hash function case using hash1() and add()///
        t.scan("gettysburg.txt", 139);

        System.out.println("\n--------------------- Specific Case ---------------------");
        ///Specific for keywords, using hashKeywords() and the addKeywords()///
        t.scan("keywords.txt", 67);
    }
}
